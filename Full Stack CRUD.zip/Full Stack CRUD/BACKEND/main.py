from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
import os
import uuid

# Initialize FastAPI app
app = FastAPI()

# MongoDB connection setup
MONGO_DETAILS = os.getenv("MONGO_URI", "mongodb+srv://hareeshnair2301:$ibi2002@cluster0.xbjtbpo.mongodb.net/")
client = AsyncIOMotorClient(MONGO_DETAILS)
database = client.taskdb
task_collection = database.get_collection("tasks")

# CORS middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500"],  # Adjust as needed for your development setup
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



# Helper function to format task data for response
def task_helper(task) -> dict:
    return {
        "task_id": task["task_id"],
        "title": task["title"],
        "description": task.get("description", ""),
        "done": task["done"]
    }

# Function to retrieve a task from MongoDB based on ID
async def retrieve_task(id: str) -> dict:
    task = await task_collection.find_one({"_id": ObjectId(id)})
    if task:
        return task_helper(task)

# Pydantic models for data validation
class TaskModel(BaseModel):
    title: str = Field(...)
    description: str = None
    due_date:str
    done: bool = False

class UpdateTaskModel(BaseModel):
    title: str = None
    description: str = None
    done: bool = None

# POST endpoint to create a new task
@app.post("/tasks", response_description="Add new task", response_model=TaskModel)
async def create_task(task: TaskModel):
      # Generate a new task ID
    task_data = {
        "title": task.title,
        "description": task.description,
        "done": task.done
    }
    
    task_data['task_id'] = str(uuid.uuid4().int)[:4]  # Assign the generated ID to task data
    new_task = await task_collection.insert_one(task_data)  # Insert task into MongoDB
      # Retrieve created task from MongoDB
    return "Data Updated Sucessfully"  # Return formatted task data as response

# GET endpoint to list all tasks
@app.get("/tasks", response_description="List all tasks", response_model=List[TaskModel])
async def get_tasks():
    tasks = []
    async for task in task_collection.find():
        tasks.append(task_helper(task))
    return tasks

# Function to validate ObjectId format
def is_valid_objectid(id_to_check: str):
    if not ObjectId.is_valid(id_to_check):
        raise HTTPException(status_code=400, detail="Invalid ObjectId")
    return ObjectId(id_to_check)

# GET endpoint to retrieve a single task by ID
@app.get("/tasks/{task_id}")
async def get_task(task_id: str):
    try:
        object_id = is_valid_objectid(task_id)
        task = await retrieve_task(object_id)
        return {"task": task}
    except HTTPException as e:
        return e

# DELETE endpoint to delete a task by ID
@app.delete("/tasks/{task_id}")
async def delete_task(task_id: str):
    try:
        object_id = is_valid_objectid(task_id)
        delete_result = await task_collection.delete_one({"_id": object_id})
        if delete_result.deleted_count == 1:
            return {"msg": "Task deleted successfully"}
        else:
            raise HTTPException(status_code=404, detail="Task not found")
    except HTTPException as e:
        return e

# PUT endpoint to update a task by ID
@app.put("/tasks/{id}", response_description="Update a task", response_model=TaskModel)
async def update_task(id: str, req: UpdateTaskModel):
    req = {k: v for k, v in req.dict().items() if v is not None}  # Filter out None values from request
    if len(req) >= 1:
        update_result = await task_collection.update_one({"_id": ObjectId(id)}, {"$set": req})  # Update task in MongoDB
        if update_result.modified_count == 1:
            updated_task = await retrieve_task(id)  # Retrieve updated task from MongoDB
            if updated_task:
                return updated_task  # Return updated task data as response
    existing_task = await retrieve_task(id)  # Retrieve existing task from MongoDB
    if existing_task:
        return existing_task  # Return existing task data as response if not updated
    raise HTTPException(status_code=404, detail=f"Task {id} not found")  # Raise exception if task not found

# Main entry point
if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8080)
