const apiUrl = 'http://127.0.0.1:8080/tasks';

document.addEventListener('DOMContentLoaded', () => {
  fetchTasks();
  document.getElementById('addTaskButton').addEventListener('click', showTaskForm);
  document.getElementById('taskForm').addEventListener('submit', saveTask);
  document.getElementById('cancelButton').addEventListener('click', hideTaskForm);
});

function fetchTasks() {
  fetch(apiUrl)
    .then(response => response.json())
    .then(tasks => renderTaskList(tasks))
    .catch(error => console.error('Error fetching tasks:', error));
}

function renderTaskList(tasks) {
  const taskList = document.getElementById('taskList');
  taskList.innerHTML = '';
  tasks.forEach(task => {
    const listItem = document.createElement('li');
    listItem.className = 'list-group-item d-flex justify-content-between align-items-center';
    listItem.innerHTML = `
      <span>${task.title}</span>
      <div>
        <button class="btn btn-warning btn-sm mr-2" onclick="editTask('${task.id}')">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteTask('${task.id}')">Delete</button>
      </div>
    `;
    taskList.appendChild(listItem);
  });
}

function showTaskForm() {
  document.getElementById('taskFormContainer').style.display = 'block';
  document.getElementById('formTitle').textContent = 'Add New Task';
  document.getElementById('taskForm').reset();
  document.getElementById('taskId').value = '';
}

function hideTaskForm() {
  document.getElementById('taskFormContainer').style.display = 'none';
}

function saveTask(event) {
  event.preventDefault();
  const id = document.getElementById('taskId').value;
  const title = document.getElementById('taskTitle').value;
  const description = document.getElementById('taskDescription').value;
  const dueDate = document.getElementById('taskDueDate').value;
  const done = document.getElementById('taskDone').checked;

  const task = { title, description, due_date: dueDate, done };

  if (id) {
    fetch(`${apiUrl}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task)
    })
    .then(response => response.json())
    .then(() => {
      hideTaskForm();
      fetchTasks();
    })
    .catch(error => console.error('Error updating task:', error));
  } else {
    fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task)
    })
    .then(response => response.json())
    .then(() => {
      hideTaskForm();
      fetchTasks();
    })
    .catch(error => console.error('Error creating task:', error));
  }
}

function editTask(id) {
  fetch(`${apiUrl}/${id}`)
    .then(response => response.json())
    .then(task => {
      document.getElementById('taskId').value = task.id;
      document.getElementById('taskTitle').value = task.title;
      document.getElementById('taskDescription').value = task.description;
      document.getElementById('taskDueDate').value = task.due_date;
      document.getElementById('taskDone').checked = task.done;
      document.getElementById('formTitle').textContent = 'Edit Task';
      showTaskForm();
    })
    .catch(error => console.error('Error fetching task:', error));
}

function deleteTask(id) {
  fetch(`${apiUrl}/${id}`, {
    method: 'DELETE'
  })
  .then(() => fetchTasks())
  .catch(error => console.error('Error deleting task:', error));
}
